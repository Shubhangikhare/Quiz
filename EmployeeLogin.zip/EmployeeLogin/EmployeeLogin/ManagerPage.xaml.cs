﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeLogin
{
    /// <summary>
    /// Interaction logic for ManagerPage.xaml
    /// </summary>
    public partial class ManagerPage : Window
    {
        public ManagerPage()
        {
            InitializeComponent();
        }
        string _myConnectionString = @"data source=ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog=training_19sep18_pune;";
        private void button_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con1 = new SqlConnection(_myConnectionString);
            con1.Open();
            SqlCommand sqlcom = new SqlCommand();
            sqlcom.CommandText
        }
    }
}
