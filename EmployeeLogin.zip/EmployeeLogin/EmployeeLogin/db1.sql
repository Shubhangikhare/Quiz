create table EmployeeLogin(
EmployeeID int identity(100,1) primary key,
EmployeeUserName  varchar(20),
EmployeePassword varchar(20))
select * from EmployeeLogin

insert into EmployeeLogin values('ShubhangiKhare','shubhi')


create procedure AddEmployees1(
@EmployeeUserName varchar(20),
@EmployeePassword varchar(20))
as begin
select EmployeeUserName,EmployeePassword from EmployeeLogin where EmployeeUserName=@EmployeeUserName and EmployeePassword=@EmployeePassword 
end
exec AddEmployees ShubhangiKhare ,shubhi



create table BookTickets(
EmployeeID int ,
TicketRequestID int identity(200,1) not null,
TicketRequestDate date not null,
Source  varchar(20) not null,
Destination varchar(20) not null,
[Current Status] varchar default 'pending')

insert into BookTickets values(101,201,'11/17/2018','pune','mumbai')
select * from BookTickets

 drop table BookTickets


 create table BookTickets(
 TicketRequestID int identity(200,1) not null,
 TicketRequestDate date,
 EmployeeID int ,
 Source  varchar(20) not null,
 Destination varchar(20) not null,
 [Current Status] varchar(20) default 'pending')

 select * from BookTickets
  

 insert into BookTickets values('11-17-2018',101,'pune','mumbai',null)
  drop proc Tickets_Booking

create procedure Tickets_Booking(
@TicketRequestDate date ,
@Source  varchar(20),
@Destination varchar(20),
@EmployeeID int
)
 as begin
 select EmployeeID,Source,Destination ,TicketRequestDate from BookTickets 
  where 
  EmployeeID=@EmployeeID and
  Source=@Source and
  Destination=@Destination and
  TicketRequestDate= @TicketRequestDate
  end
exec Tickets_Booking


  CREATE TABLE ManagerLogin(
  UserName varchar(30) not null unique,
  Password varchar(30) not null)
 
  