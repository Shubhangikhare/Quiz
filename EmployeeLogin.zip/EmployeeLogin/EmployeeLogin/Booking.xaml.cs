﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeLogin
{
    /// <summary>
    /// Interaction logic for Booking.xaml
    /// </summary>
    public partial class Booking : Window
    {
        public Booking()
        {
            InitializeComponent();
        }

        string _myConnectionString = @"data source=ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog=training_19sep18_pune;";
        private void button_Click(object sender, RoutedEventArgs e)
        {

            SqlConnection con1 = new SqlConnection(_myConnectionString);
            con1.Open();
            SqlCommand sqlcom = new SqlCommand();
            sqlcom.CommandText = "Tickets_Booking";
            sqlcom.Connection = con1;
            sqlcom.Parameters.AddWithValue("@EmployeeID", txtEmpID.Text);
            sqlcom.Parameters.AddWithValue("@TicketRequestDate",txtRDate.Text);
            sqlcom.Parameters.AddWithValue("@Source", txtSource.Text);
            sqlcom.Parameters.AddWithValue("@Destination", txtDestination.Text);
            sqlcom.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader dr = sqlcom.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                
                MessageBox.Show("Submitted");
               // var Tkt = new Manager();
                //Tkt.Show();
            }
            else
            {
                MessageBox.Show("invalid");
            }
            con1.Close();

        }

    }
}

